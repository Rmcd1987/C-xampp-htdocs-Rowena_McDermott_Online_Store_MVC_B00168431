<?php
session_start();
require_once '../controllers/CartController.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$cartController = new CartController();

// ✅ Handle all form actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_to_cart'])) {
        $productId = (int)$_POST['product_id'];
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        $cartController->addToCart($productId, $quantity);
        header('Location: cart.php');
        exit;
    }

    if (isset($_POST['update_quantity'])) {
        $productId = (int)$_POST['product_id'];
        $quantity = max((int)$_POST['quantity'], 1);
        $cartController->updateQuantity($productId, $quantity);
        header('Location: cart.php');
        exit;
    }

    if (isset($_POST['remove'])) {
        $cartController->removeFromCart((int)$_POST['product_id']);
        header('Location: cart.php');
        exit;
    }

    if (isset($_POST['clear_cart'])) {
        $cartController->clearCart();
        header('Location: cart.php');
        exit;
    }
}

$cartItems = $cartController->getCartItems();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Cart - CelticCharm Accessories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include '../views/header.php'; ?>

<div class="container my-5">
    <h1 class="text-center mb-4">🛒 Your Cart</h1>

    <?php if (empty($cartItems)): ?>
        <div class="alert alert-info text-center">
            Your cart is currently empty.
        </div>
        <div class="text-center">
            <a href="index.php" class="btn btn-primary">Continue Shopping</a>
        </div>
    <?php else: ?>
        <form method="post" class="text-end mb-4">
            <button type="submit" name="clear_cart" class="btn btn-danger">Clear Cart</button>
        </form>

        <div class="row">
            <?php foreach ($cartItems as $item): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="images/<?= htmlspecialchars($item['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($item['name']) ?>" style="height: 250px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($item['name']) ?></h5>
                            <p class="card-text">€<?= htmlspecialchars($item['price']) ?></p>

                            <form method="post" class="mt-auto">
                                <input type="hidden" name="product_id" value="<?= $item['id'] ?>">

                                <div class="mb-2">
                                    <label for="quantity_<?= $item['id'] ?>" class="form-label">Quantity:</label>
                                    <input type="number" name="quantity" id="quantity_<?= $item['id'] ?>" value="<?= htmlspecialchars($item['quantity']) ?>" min="1" class="form-control">
                                </div>

                                <button type="submit" name="update_quantity" class="btn btn-outline-primary w-100 mb-2">Update Quantity</button>
                                <button type="submit" name="remove" class="btn btn-outline-danger w-100">Remove</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-5">
            <a href="index.php" class="btn btn-success me-2">Continue Shopping</a>
            <a href="checkout.php" class="btn btn-warning">Proceed to Payment</a>
        </div>
    <?php endif; ?>
</div>

<?php include '../views/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
