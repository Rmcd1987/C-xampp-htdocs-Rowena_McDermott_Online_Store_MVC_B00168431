<?php
session_start();
session_unset(); // optional: clears session variables
session_destroy(); // destroys the session
header('Location: login.php'); // redirect to login page
exit;
?>
