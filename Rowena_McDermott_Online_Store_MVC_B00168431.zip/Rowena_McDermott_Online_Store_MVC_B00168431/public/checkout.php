<?php
session_start();
require_once '../controllers/CartController.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$cartController = new CartController();
$cartItems = $cartController->getCartItems();

// Calculate total
$total = 0;
foreach ($cartItems as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout - CelticCharm Accessories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include '../views/header.php'; ?>

<div class="container my-5">
    <h1 class="text-center mb-4">🧾 Checkout</h1>

    <?php if (empty($cartItems)): ?>
        <div class="alert alert-warning text-center">Your cart is empty. <a href="index.php">Shop now</a></div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-6">
                <h4>Billing Information</h4>
                <form action="thankyou.php" method="post">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="address" class="form-label">Address</label>
                        <textarea id="address" name="address" class="form-control" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="card" class="form-label">Card Number</label>
                        <input type="text" id="card" name="card" class="form-control" placeholder="0000 0000 0000 0000" required>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Confirm & Pay €<?= number_format($total, 2) ?></button>
                </form>
            </div>

            <div class="col-md-6">
                <h4>Order Summary</h4>
                <ul class="list-group">
                    <?php foreach ($cartItems as $item): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?= htmlspecialchars($item['name']) ?> x <?= $item['quantity'] ?>
                            <span>€<?= number_format($item['price'] * $item['quantity'], 2) ?></span>
                        </li>
                    <?php endforeach; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center fw-bold">
                        Total
                        <span>€<?= number_format($total, 2) ?></span>
                    </li>
                </ul>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../views/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
