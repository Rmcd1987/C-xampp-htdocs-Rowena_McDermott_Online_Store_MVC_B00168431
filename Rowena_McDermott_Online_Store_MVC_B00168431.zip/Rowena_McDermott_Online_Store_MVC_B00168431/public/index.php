<?php
session_start();
require_once '../models/Product.php';

$productModel = new Product();
$products = $productModel->getAll();

require_once '../views/header.php';
?>

<div class="container mt-4">
    <h1 class="text-center mb-5">Welcome to CelticCharm Accessories</h1>

    <div class="row">
        <?php foreach ($products as $product): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow">
                    <img src="images/<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>" style="height: 250px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                        <p class="card-text">€<?= htmlspecialchars($product['price']) ?></p>
                        <p class="card-text small text-muted"><?= htmlspecialchars($product['description']) ?></p>

                        <form action="cart.php" method="post" class="mt-auto">
                            <input type="hidden" name="product_id" value="<?= $product['id'] ?>">

                            <!-- ✅ Quantity input -->
                            <div class="mb-2">
                                <label for="quantity_<?= $product['id'] ?>" class="form-label">Quantity:</label>
                                <input type="number" name="quantity" id="quantity_<?= $product['id'] ?>" class="form-control" value="1" min="1">
                            </div>

                            <button type="submit" name="add_to_cart" class="btn btn-warning w-100">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once '../views/footer.php'; ?>
