<?php
session_start();
require_once '../models/User.php';

if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    if ($password === $confirm_password) {
        $userModel = new User();
        $userModel->register($username, $email, $password);

        header('Location: login.php');
        exit;
    } else {
        $error = "Passwords do not match!";
    }
}
require_once '../views/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="mb-4 text-center">Create an Account</h2>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="post">
                <div class="mb-3">
                    <label>Username:</label>
                    <input type="text" name="username" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Email:</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Password:</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Confirm Password:</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>

                <button type="submit" name="register" class="btn btn-success w-100">Register</button>
            </form>

            <p class="text-center mt-3">Already registered? <a href="login.php">Login here</a></p>
        </div>
    </div>
</div>

<?php require_once '../views/footer.php'; ?>
