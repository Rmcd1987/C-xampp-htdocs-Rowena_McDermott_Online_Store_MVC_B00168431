# 🎀 CelticCharm Accessories – MVC Online Store

Welcome to **CelticCharm Accessories**, a stylish fictional online shop for Irish accessories. This PHP-based web application was built for a Web Application Development project using the **Model-View-Controller (MVC)** design pattern. It includes login/logout, registration, product listings, a Bootstrap-styled shopping cart, session-based authentication, and MySQL database integration.

---

## 📂 Folder Structure

```
CelticCharm_Accessories/
├── public/         # Public-facing files (index, login, register, cart, checkout)
├── views/          # Reusable header/footer templates
├── models/         # User and Product classes
├── controllers/    # Cart controller
├── database/       # SQL schema file and DB connection
└── README.md       # Project overview and setup
```

---

## ✨ Features

- ✅ **User Registration & Login** (with password hashing)
- 🛍️ **Product Catalog** (retrieved dynamically from MySQL)
- ➕ **Add to Cart** with quantity selection
- 🗑️ **Update / Remove / Clear Cart** with session storage
- 🧾 **Checkout Page**
- 👮 **Session-Based Authentication**
- 💅 **Bootstrap 5 Styling** for mobile-responsive design
- 🧼 **Form Validation & Sanitisation** (client & server side)
- 🔁 **MVC Code Organisation**

---

## 💾 Requirements

- PHP 7.4 or later
- MySQL (phpMyAdmin preferred)
- Apache (XAMPP, WAMP, or MAMP)
- Web browser (Chrome, Firefox, Edge, Safari, etc.)

---

## 🚀 Setup Instructions (Beginner-Friendly)

1. **Place Project Folder**
   - Copy the entire folder into:  
     `C:/xampp/htdocs/`

2. **Create the Database**
   - Visit: `http://localhost/phpmyadmin`
   - Click **New** → Name the database: `store`
   - Click **Import** → Select: `database/schema.sql` → Click **Go**

3. **Launch the Website**
   - In browser:  
     [http://localhost/Rowena_McDermott_Online_Store_MVC_B00168431/public/login.php]
   - Register a new user → Login → Browse and shop!

---

## 🧠 Learning Objectives Demonstrated

| ✅ Objective                             | Demonstrated In                |
|----------------------------------------|--------------------------------|
| MVC Design Pattern                     | Full folder & file structure   |
| Login System with Sessions             | `login.php`, `register.php`   |
| Shopping Cart Logic                    | `cart.php`, `CartController.php` |
| PDO with MySQL CRUD                    | `User.php`, `Product.php`     |
| Session Management                     | Auth protection in `header.php` |
| Bootstrap Styling                      | All public pages               |
| Form Validation (Client + Server Side) | Login/Register + Cart          |
| Readable Code (DRY)                    | Classes + separate logic       |

---

## 📸 Screenshots

| Homepage | Product Detail | Cart Page | Register |
|----------|----------------|-----------|----------------|
| ![Home](screenshots/home.png) | ![Product](screenshots/products.png) | ![Cart](screenshots/cart.png) | ![Login](screenshots/register.png) |

---

## 📬 Submission Details

- **GitHub Repository**: https://github.com/Rmcd1987/C-xampp-htdocs-Rowena_McDermott_Online_Store_MVC_B00168431.git
- **Zip Upload**: Includes all PHP files, schema.sql, README
- **No plagiarism**: Fully original and educational

---

## 👩‍🎓 Student Details

- **Name**: Rowena McDermott  
- **Student ID**: B00168431  
- **Module**: Web Application Development  
- **Year**: 2025  
- **Instructor**: Robert Smith

---

## ❤️ Thank You

This project was created to explore core backend development concepts in PHP, MySQL, and secure web programming.  
Enjoy shopping with CelticCharm Accessories!