<?php
require_once __DIR__ . '/../database/db.php';

class User
{
    private $db;

    public function __construct()
    {
        global $pdo;
        $this->db = $pdo;
    }

    // DO NOT HASH PASSWORD FOR NOW
    public function register($username, $email, $password)
    {
        // Store password as plain text for now (development only)
        $stmt = $this->db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        return $stmt->execute([$username, $email, $password]);
    }

    public function login($email, $password)
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // DIRECT STRING MATCH - NO HASH
        if ($user && $user['password'] === $password) {
            return $user;
        }
        return false;
    }
}
