<?php
session_start();
require_once '../models/Product.php';
require_once '../models/Cart.php';
require_once '../views/header.php';

// Redirect if not logged in
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$cart = new Cart();
$productModel = new Product();

// Handle add/remove/clear
if (isset($_POST['add_to_cart'])) {
    $productId = (int)$_POST['product_id'];
    $cart->add($productId);
    header('Location: cart.php');
    exit;
}

if (isset($_POST['remove'])) {
    $productId = (int)$_POST['product_id'];
    $cart->remove($productId);
    header('Location: cart.php');
    exit;
}

if (isset($_POST['clear_cart'])) {
    $cart->clear();
    header('Location: cart.php');
    exit;
}

// Get cart items
$cartItems = $cart->getCart();
$allProducts = $productModel->getAll();
?>

<h1 class="text-center mb-5">Your Shopping Cart</h1>

<div class="text-center mb-4">
    <a href="index.php" class="btn btn-outline-primary">← Continue Shopping</a>
    <form action="cart.php" method="post" class="d-inline">
        <button type="submit" name="clear_cart" class="btn btn-outline-danger">Clear Cart</button>
    </form>
</div>

<?php if (empty($cartItems)): ?>
    <div class="alert alert-info text-center">Your cart is empty.</div>
<?php else: ?>
    <div class="row">
        <?php foreach ($cartItems as $itemId): ?>
            <?php foreach ($allProducts as $product): ?>
                <?php if ($product['id'] == $itemId): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100 shadow-sm">
                            <img src="images/<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>" style="height: 250px; object-fit: cover;">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                                <p class="card-text">€<?= htmlspecialchars($product['price']) ?></p>

                                <form action="cart.php" method="post" class="mt-auto">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" name="remove" class="btn btn-danger w-100">Remove</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>

    <!-- 🟨 Buttons under cart items -->
    <div class="d-flex justify-content-center mt-4 gap-3">
        <a href="index.php" class="btn btn-primary px-4">Continue Shopping</a>
        <a href="checkout.php" class="btn btn-warning px-4">Proceed to Payment</a>
    </div>
<?php endif; ?>

<?php require_once '../views/footer.php'; ?>
